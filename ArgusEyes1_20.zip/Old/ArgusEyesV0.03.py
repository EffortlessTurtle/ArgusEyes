#       <YarnWeb, webscraper to pull news stories, v0.03>
#
########################################################################
#       <TODO>
# -finish other methods to scrape other sites
# -print all to a txt doc for user review
# -eventually to be hosted and then emails? result every 2 hours to a special account
#
#
#
#########################################################################


# imports
import requests
import progressbar
import time
from bs4 import BeautifulSoup
import datetime as dt
from dateutil import parser


# classes

class Tyler:
    def __init__(self):
        pass
        
        
    
    def datefix_epoch(date_to_fix): #doesn't need self, Doesn't need anything else in the class.
            df = date_to_fix    
            df.strip()
            parsed = parser.parse(date_to_fix)
            #print(str(parsed))
            return parsed



#Globals

fo = open(f'/home/nate/Desktop/News/{str(dt.date.today())}.txt', "w")

# functions
def pro_bar1(): #code for the spinny slash, Not a used FXN      
    widgets = ['Loading: ', progressbar.AnimatedMarker()]
    bar = progressbar.ProgressBar(widgets=widgets).start()
      
    for i in range(50):
        time.sleep(0.1)
        bar.update(i)

def epoch_US():  # Pulls title, blurb and date written for Epoch US
    """This is the logic to pull headlines.
    TODO:
    -write to a txt document 
    """
    url = 'https://www.theepochtimes.com/c-us'
    response = requests.get(url)
    text = response.text
    data = BeautifulSoup(text, 'html.parser')
    widgets = ['Fetching Epoch - US: ', progressbar.AnimatedMarker()]
    bar = progressbar.ProgressBar(widgets=widgets).start() 
    #cur_date = dt.date.today()
    #dat = Tyler.datefix_epoch(str(cur_date))
    #print(str(dat))
    #print(cur_date)
    #print("\n__The Epoch Times - US News__\n")
    fo.write(15 * ' ' + '__The Epoch Times - US News__\n\n')
    fo.write(140 * "^" + '\n\n')
    # print(data)  #NOTE: signpost, prints raw HTML output of page
    for x in range(2, 6):
        #print(url)
        response = requests.get(url)  # -MARK
        # -MARK    NOTE: marked must stay here, otherwise you never request the next page's content from website
        #print(url)
        text = response.text
        data = BeautifulSoup(text, 'html.parser')  # -MARK
        # For loop through each container for title, time and who reported
        for tag in data.find_all(class_="article_info text"):
            
            # get title of article
            title = tag.find(class_='title').text.strip(
            ) if tag.find(class_='title') else ''
            # Get the short news excerpt
            more_info = tag.find(class_='excerpt more_info').text.strip(
            ) if tag.find(
                class_='excerpt more_info') else 'No Info Availabe'
            # Get Date article was written
            date = tag.find(class_='time').text.strip(
            ) if tag.find(class_='time') else 'No date available'
        
            #print('\033[1m' + title + '\033[0m')  # KEEP: makes title bold
            #print(more_info)  # KEEP
            #print(date + '\n')  # KEEP
            fo.write(str(date) + "\n")
            fo.write(title + "\n")
            fo.write(more_info + "\n" + 140 * '-'+"\n")
            fo.write('\n')
            bar.update(1)
        url = f"https://www.theepochtimes.com/c-us/" + str(x)
        
    print("\n"+'Epoch - US: fetched')
        
def epoch_latest():  # Pulls title, blurb and date written for Epoch latest
    """This is the logic to pull headlines.    """
    
    url = 'https://www.theepochtimes.com/latest/'
    response = requests.get(url)
    text = response.text
    data = BeautifulSoup(text, 'html.parser')
    widgets = ['Fetching Epoch - Latest: ', progressbar.AnimatedMarker()]
    bar = progressbar.ProgressBar(widgets=widgets).start()
    #cur_date = dt.date.today() 
    #dat = Tyler.datefix_epoch(str(cur_date))
    #print(str(dat))
    #print(cur_date)
    #print("\n__The Epoch Times - Latest News__\n")
    i = 0
    fo.write(15 * ' ' + '__The Epoch Times - Latest News__\n\n')
    fo.write(140 * "^" + '\n\n')
    # print(data)  #NOTE: signpost, prints raw HTML output of page
    for x in range(2, 3):
        
        #print(url)
        response = requests.get(url)  # -MARK
        # -MARK    NOTE: marked must stay here, otherwise you never request the next page's content from website
        text = response.text
        data = BeautifulSoup(text, 'html.parser')  # -MARK
        # For loop through each container for title, time and who reported
        for tag in data.find_all(class_="article_info text"):

            # get title of article
            title = tag.find(class_='title').text.strip(
            ) if tag.find(class_='title') else ''
            # Get the short news excerpt
            more_info = tag.find(class_='excerpt more_info').text.strip(
            ) if tag.find(
                class_='excerpt more_info') else 'No Info Availabe'
            # Get Date article was written
            date = tag.find(class_='time').text.strip(
            ) if tag.find(class_='time') else 'No date available'

            date2 = parser.parse(date)
            #print(date2)
            #print(dt.date.today())
            if date2 != dt.date.today():  # counter to
                
                #print(' <- inside if, date2; i, epoch_latest()')
                fo.write(str(date) + "\n")
                fo.write(title + "\n")
                fo.write("\n")
                fo.write(more_info + "\n" + 140 * '-'+"\n")
                fo.write('\n')
                bar.update(1)
                i += 1
            else:

                #print(' <- i, epoch_latest();else, inside epoch_latest')
                fo.write(str(date) + "\n")
                fo.write(title + "\n")
                fo.write("\n")
                fo.write(more_info + "\n" + 140 * '-'+"\n")
                fo.write('\n')
                bar.update(1)
            
        if i >= 29: #this is an emergency to kill any accidental race-condition
            print(str(i) + ' <- emergency break, EPOCH - LATEST')
            i = 0
            continue  #This break kicks from x in (2,12) for loop
        elif i >100:
            break
        #print(i)
        url = f"https://www.theepochtimes.com/latest/" + str(x)
        
    print(("\n"+'Epoch - Latest: fetched'))
    
def epoch_USPol():  # Pulls title, blurb and date written for Epoch latest
    """This is the logic to pull headlines.    """
    
    url = 'https://www.theepochtimes.com/c-us-politics'
    response = requests.get(url)
    text = response.text
    data = BeautifulSoup(text, 'html.parser')
    widgets = ['Fetching Epoch - US Politics: ', progressbar.AnimatedMarker()]
    bar = progressbar.ProgressBar(widgets=widgets).start()
    #cur_date = dt.date.today() 
    #dat = Tyler.datefix_epoch(str(cur_date))
    #print(str(dat))
    #print(cur_date)
    #print("\n__The Epoch Times - Latest News__\n")
    i = 0
    fo.write(15 * ' ' + '__The Epoch Times - US Politics__\n\n')
    fo.write(140 * "^" + '\n\n')
    # print(data)  #NOTE: signpost, prints raw HTML output of page
    
    for tag in data.find_all(class_="post_list"):

        # get title of article
        title = tag.find(class_='title').text.strip(
        ) if tag.find(class_='title') else ''
        # Get the short news excerpt
        more_info = tag.find(class_='excerpt more_info').text.strip(
        ) if tag.find(
            class_='excerpt more_info') else 'No Info Availabe'
        # Get Date article was written
        date = tag.find(class_='time').text.strip(
        ) if tag.find(class_='time') else 'No date available'

        date2 = parser.parse(date)
        #print(date2)
        #print(dt.date.today())
        if date2 != dt.date.today():  # counter to
            
            #print(' <- inside if, date2; i, epoch_latest()')
            fo.write(str(date) + "\n")
            fo.write(title + "\n")
            fo.write("\n")
            fo.write(more_info + "\n" + 140 * '-'+"\n")
            fo.write('\n')
            bar.update(1)
            i += 1
        else:

            #print(' <- i, epoch_latest();else, inside epoch_latest')
            fo.write(str(date) + "\n")
            fo.write(title + "\n")
            fo.write("\n")
            fo.write(more_info + "\n" + 140 * '-'+"\n")
            fo.write('\n')
            bar.update(1)
        
        if i >= 29: #this is an emergency to kill any accidental race-condition
            print(str(i) + ' <- emergency break, epoch_USPol')
            i = 0
            continue  #This break kicks from x in (2,12) for loop
        elif i >100:
            break
        #print(i)
        
    print(("\n"+'Epoch - US Politics: fetched'))    
    
def epoch_World():        #Pulls title, blurb and date - BBC world
    """this pulls the bbc world news
    ++++
    NOTE:
    -this one has very long class names. and is the template of many of its contemporaries.
    """
    #These are for websites where there's one HUGE headline with a bunch of little ones to follow
    #bold_container = "gs-c-promo-body gs-u-mt@xxs gs-u-mt@m gs-c-promo-body--primary gs-u-mt@xs gs-u-mt@s gs-u-mt@m gs-u-mt@xl gel-1/3@m gel-1/2@xl gel-1/1@xxl"
    #bold_title = "gs-c-promo-heading__title gel-paragon-bold gs-u-mt+ nw-o-link-split__text"
    #bold_more_info = "gs-c-promo-summary gel-long-primer gs-u-mt nw-c-promo-summary"
    #p_bold = data.find(class_=bold_container)
    #p_bold_title = p_bold.find(class_=bold_title).text.strip() if p_bold.find(class_=bold_title) else ''
    #p_bold_more_info = p_bold.find(class_=bold_more_info).text.strip() if p_bold.find(class_=bold_more_info) else ''
    #fo.write(str(dt.datetime.now()) + '\n')
    #fo.write(str(p_bold_title) + '\n')
    #fo.write('\n')
    #fo.write(str(p_bold_more_info) + '\n' + 140 * '-' + '\n' + '\n')
    #bar.update(1)
    
    url = 'https://www.theepochtimes.com/c-world'
    response = requests.get(url)
    text = response.text
    data = BeautifulSoup(text, 'html.parser')
    widgets = ['Fetching Epoch - World: ', progressbar.AnimatedMarker()]
    bar = progressbar.ProgressBar(widgets=widgets).start()
    fo.write(15 * ' ' + '__ Epoch - World __\n\n')
    fo.write(140 * "^" + '\n\n')
    container_class_stand_in = "post_list"
    title_class_stand_in = "title"
    excerpt_class_stand_in = "excerpt more_info"
    time_class_stand_in = "time"
    response = requests.get(url)  # -MARK
    text = response.text
    data = BeautifulSoup(text, 'html.parser')  # -MARK
    
    # For loop through each container for title, time and who reported
    for tag in data.find_all(class_=container_class_stand_in):

        # get title of article
        title = tag.find(class_=title_class_stand_in).text.strip(
        ) if tag.find(class_=title_class_stand_in) else ''
        # Get the short news excerpt
        more_info = tag.find(class_=excerpt_class_stand_in).text.strip(
        ) if tag.find(
            class_=excerpt_class_stand_in) else '\nEpoch - World'
        # Get Date article was written
        try:
            date = tag.find(class_=time_class_stand_in).datetime.text.strip()
        except AttributeError:
            date = ''
        #write to file section
        fo.write(str(date) + "\n")
        fo.write(title + "\n")
        fo.write("\n")
        fo.write(more_info + "\n" + 140 * '-'+"\n")
        fo.write('\n')
        bar.update(1)
        
    print("\nEpoch - World: fetched")   

def BBC_World():        #Pulls title, blurb and date - BBC world
    """this pulls the bbc world news
    ++++
    NOTE:
    -this one has very long class names. and is the template of many of its contemporaries.
    """
    url = 'https://www.bbc.com/news/world'
    response = requests.get(url)
    text = response.text
    data = BeautifulSoup(text, 'html.parser')
    widgets = ['Fetching BBC - World: ', progressbar.AnimatedMarker()]
    bar = progressbar.ProgressBar(widgets=widgets).start()
    #cur_date = dt.date.today() 
    #dat = Tyler.datefix_epoch(str(cur_date))
    #print(str(dat))
    #print(cur_date)
    #print("\n__ BBC - WORLD __\n")
    i = 0
    fo.write(15 * ' ' + '__ BBC - WORLD __\n\n')
    fo.write(140 * "^" + '\n\n')
    # print(data)  #NOTE: signpost, prints raw HTML output of page
    container_class_stand_in = "gs-c-promo-body gs-u-mt@xxs gs-u-mt@m gs-c-promo-body--flex gs-u-mt@xs gs-u-mt0@xs gs-u-mt@m gel-1/2@xs gel-1/1@s"
    title_class_stand_in = "gs-c-promo-heading__title gel-pica-bold nw-o-link-split__text"
    excerpt_class_stand_in = "gs-c-promo-summary gel-long-primer gs-u-mt nw-c-promo-summary gs-u-display-none gs-u-display-block@m"
    time_class_stand_in = "gs-o-bullet__text date qa-status-date"
    response = requests.get(url)  # -MARK
    text = response.text
    data = BeautifulSoup(text, 'html.parser')  # -MARK
    bold_container = "gs-c-promo-body gs-u-mt@xxs gs-u-mt@m gs-c-promo-body--primary gs-u-mt@xs gs-u-mt@s gs-u-mt@m gs-u-mt@xl gel-1/3@m gel-1/2@xl gel-1/1@xxl"
    bold_title = "gs-c-promo-heading__title gel-paragon-bold gs-u-mt+ nw-o-link-split__text"
    bold_more_info = "gs-c-promo-summary gel-long-primer gs-u-mt nw-c-promo-summary"
    
    
    p_bold = data.find(class_=bold_container)
    p_bold_title = p_bold.find(class_=bold_title).text.strip() if p_bold.find(class_=bold_title) else ''
    p_bold_more_info = p_bold.find(class_=bold_more_info).text.strip() if p_bold.find(class_=bold_more_info) else ''
    
    fo.write(str(dt.datetime.now()) + '\n')
    fo.write(str(p_bold_title) + '\n')
    fo.write('\n')
    fo.write(str(p_bold_more_info) + '\n' + 140 * '-' + '\n' + '\n')
    bar.update(1)
    # For loop through each container for title, time and who reported
    for tag in data.find_all(class_=container_class_stand_in):

        # get title of article
        title = tag.find(class_=title_class_stand_in).text.strip(
        ) if tag.find(class_=title_class_stand_in) else ''
        # Get the short news excerpt
        more_info = tag.find(class_=excerpt_class_stand_in).text.strip(
        ) if tag.find(
            class_=excerpt_class_stand_in) else 'BBC - World'
        # Get Date article was written
        try:
            date = tag.find(class_=time_class_stand_in).datetime.text.strip()
        except AttributeError:
            date = ''
        #write to file section
        fo.write(str(date) + "\n")
        fo.write(title + "\n")
        fo.write("\n")
        fo.write(more_info + "\n" + 140 * '-'+"\n")
        fo.write('\n')
        bar.update(1)
        i += 1
        if i > 30:
            print("emergency break, BBC - WORLD")
            break
    print("\nBBC - World: fetched")   
    
def BBC_UK():        #Pulls title, blurb and date - BBC UK
    """this pulls the bbc UK news
    ++++
    NOTE:
    -this one has very long class names. and is the template of many of its contemporaries.
    """
    url = 'https://www.bbc.com/news/uk'
    response = requests.get(url)
    text = response.text
    data = BeautifulSoup(text, 'html.parser')
    widgets = ['Fetching BBC - UK: ', progressbar.AnimatedMarker()]
    bar = progressbar.ProgressBar(widgets=widgets).start()
    #cur_date = dt.date.today() 
    #dat = Tyler.datefix_epoch(str(cur_date))
    #print(str(dat))
    #print(cur_date)
    #print("\n__ BBC - WORLD __\n")
    i = 0
    fo.write(15 * ' ' + '__ BBC - UK __\n\n')
    fo.write(140 * "^" + '\n\n')
    # print(data)  #NOTE: signpost, prints raw HTML output of page
    container_class_stand_in = "gs-c-promo gs-t-News nw-c-promo gs-o-faux-block-link gs-u-pb gs-u-pb+@m nw-p-default gs-c-promo--inline gs-c-promo--stacked@m gs-c-promo--flex"
    title_class_stand_in = "gs-c-promo-heading__title gel-pica-bold nw-o-link-split__text"
    excerpt_class_stand_in = "gs-c-promo-summary gel-long-primer gs-u-mt nw-c-promo-summary gs-u-display-none gs-u-display-block@m"
    time_class_stand_in = "gs-o-bullet__text date qa-status-date"
    response = requests.get(url)  # -MARK #gets the request from the website
    text = response.text # -MARK, makes typing much easier
    data = BeautifulSoup(text, 'html.parser')  # -MARK, Parses the data and makes more readable
    
    #To pull the big headline from BBC - UK site
    bold_container = "gs-c-promo gs-t-News nw-c-promo gs-o-faux-block-link gs-u-pb gs-u-pb+@m nw-p-default gs-c-promo--inline@m gs-c-promo--stacked@xxl gs-c-promo--flex"
    bold_title = "gs-c-promo-heading__title gel-paragon-bold gs-u-mt+ nw-o-link-split__text"
    bold_more_info = "gs-c-promo-summary gel-long-primer gs-u-mt nw-c-promo-summary"
    p_bold = data.find(class_=bold_container)
    p_bold_title = p_bold.find(class_=bold_title).text.strip() if p_bold.find(class_=bold_title) else ''
    p_bold_more_info = p_bold.find(class_=bold_more_info).text.strip() if p_bold.find(class_=bold_more_info) else ''
    
    fo.write(str(dt.datetime.today()) + '\n')
    fo.write("\n"+str(p_bold_title) + '\n')
    fo.write('\n')
    fo.write(str(p_bold_more_info) + '\n' + 140 * '-' + '\n' + '\n')
    bar.update(1)
    # For loop through each container for title, time and who reported
    for tag in data.find_all(class_=container_class_stand_in):

        # get title of article
        title = tag.find(class_=title_class_stand_in).text.strip(
        ) if tag.find(class_=title_class_stand_in) else ''
        # Get the short news excerpt
        more_info = tag.find(class_=excerpt_class_stand_in).text.strip(
        ) if tag.find(
            class_=excerpt_class_stand_in) else 'BBC - UK'
        # Get Date article was written
        try:
            date = tag.find(class_=time_class_stand_in).datetime.text()
        except AttributeError:
            date = ''
        #write to file section
        fo.write(str(date) + "\n")
        fo.write(title + "\n")
        fo.write("\n")
        fo.write(more_info + "\n" + 140 * '-'+"\n")
        fo.write('\n')
        bar.update(1)
        i += 1
        if i > 30:
            print("emergency break, BBC - WORLD")
            break
    print("\nBBC - UK: fetched")   

    

# -----main-----
def main():
   epoch_latest()
   
   epoch_US()
   
   epoch_USPol()
   
   BBC_World()
   epoch_World()
   
   BBC_UK()

# ___RUNNING PARTS___
#epoch_US()
#epoch_latest()
#datefix_epoch('APRIL 1 2022')
main()


#       <other NOTE space>
#
#
#
#
#
#
