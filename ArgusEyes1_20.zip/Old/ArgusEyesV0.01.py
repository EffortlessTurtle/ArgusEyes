#       <YarnWeb, webscraper to pull news stories, v0.01>
#
########################################################################
#       <TODO>
#-finish other methods to scrape other sites
#-print all to a txt doc for user review
#-eventually to be hosted and then emails? result every 2 hours to a special account
#
#
#
#########################################################################


#imports
import requests
from bs4 import BeautifulSoup
import datetime as dt


#classes




#functions
def epoch_US():  #Pulls title, blurb and date written for Epoch US
    """This is the logic to pull headlines.
    TODO:
    -Make it filter by date
    -make it look through pages with <path>/<num> generating the new num until 25 of yesterday's news
    is printed
    -write to a txt document 
    """
    
    url = 'https://www.theepochtimes.com/c-us'
    response = requests.get(url)
    text = response.text
    data = BeautifulSoup(text, 'html.parser')
    
    print(dt.date.today())
    print("\n__The Epoch Times - US News__\n")
    #print(data)  #NOTE: signpost, prints raw HTML output of page
    #i = 0
    #for x in (2,12)
    #response = requests.get(url) #-MARK
    #text = response.text #-MARK    NOTE: marked must stay here, otherwise you never request the next page's content from website
    #data = BeautifulSoup(text, 'html.parser') #-MARK
    for tag in data.find_all(class_="article_info text"): #For loop through each container for title, time and who reported
        
        #get title of article
        title = tag.find(class_='title').text.strip() if tag.find(class_='title') else ''
        #Get the short news excerpt
        more_info = tag.find(class_='excerpt more_info').text.strip() if tag.find(class_='excerpt more_info') else 'No Info Availabe'
        #Get Date article was written
        date = tag.find(class_='time').text.strip() if tag.find(class_='time') else 'No date available'
        
        #if date!=dt.datetime.today()
        #   i+=1
        
        print('\033[1m' + title +'\033[0m') #KEEP: makes title bold 
        print(more_info)  #KEEP
        print(date + '\n')  #KEEP
        #
        #if i == 25:
        #   break
    #url = f"https://www.theepochtimes.com/c-us/{x}"



#-----main-----
epoch_US()

# ___RUNNING PARTS___



#       <other NOTE space>
#
#
#
#
#
#